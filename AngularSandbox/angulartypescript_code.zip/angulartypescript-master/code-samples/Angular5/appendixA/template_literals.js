var customerName = "John Smith";
console.log(`Hello ${customerName}`);

function getCustomer(){
  return "Allan Lou";
}
console.log(`Hello ${getCustomer()}`);
function calcTaxES6(income, state = "Florida") {

  console.log("ES6. Calculating tax for the resident of " + state +
                                  " with the income " + income);
}

calcTaxES6(50000);
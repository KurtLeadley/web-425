import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/restclientpost/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/restclientform/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);

export * from './product-detail.component';

import { ProductService } from './product.service';

export { Product, ProductSearchParams, ProductService } from './product.service';

export const SHARED_SERVICES = [
  ProductService
];

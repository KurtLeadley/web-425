export const environment = {
  production: true,
  apiBaseUrl: '/',
  wsUrl: '/'
};

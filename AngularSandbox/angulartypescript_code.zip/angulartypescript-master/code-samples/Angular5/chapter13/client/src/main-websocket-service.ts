import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/wsservice/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
